import azure.functions as func
import logging
import json
import sys
import os

# Ensure we can import toy_agent
# In Azure Functions, the root is usually the app directory, so local imports should work.
from toy_agent import ToyExecutor

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="run")
def run_toy_agent(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Toy Agent HTTP trigger function processed a request.')

    try:
        req_body = req.get_json()
    except ValueError:
        return func.HttpResponse(
             "Invalid JSON body. Please provide 'script' and 'inputs'.",
             status_code=400
        )

    script = req_body.get('script')
    inputs = req_body.get('inputs', [])

    if not script:
        return func.HttpResponse(
             "Please pass a 'script' in the request body",
             status_code=400
        )

    output_buffer = []
    # Reverse inputs to pop from end (efficiently acting as a queue)
    input_queue = list(inputs)
    input_queue.reverse()

    def custom_input(prompt: str = ""):
        if not input_queue:
            raise RuntimeError("Script asked for input but no more inputs provided in request.")
        return input_queue.pop()

    def custom_output(text: str):
        output_buffer.append(text)

    try:
        # Instantiate executor with our custom handlers
        executor = ToyExecutor(script=None, input_handler=custom_input, output_handler=custom_output)
        executor.load_script(script)
        
        response_data = {
            "output": output_buffer,
            "status": "success"
        }
        return func.HttpResponse(
             json.dumps(response_data),
             mimetype="application/json",
             status_code=200
        )

    except Exception as e:
        error_response = {
            "output": output_buffer,
            "status": "error",
            "error": str(e)
        }
        return func.HttpResponse(
             json.dumps(error_response),
             mimetype="application/json",
             status_code=500
        )
